import java.io.*;

public class Interface {
	 public static void main (String[] args ) throws IOException{
		 
	        InputStreamReader isr = new InputStreamReader(System.in);
	        
	        BufferedReader br = new BufferedReader(isr);
	        
	        Sistema entrada = new Sistema();
	        
	        int AndaresPredio=Integer.parseInt(br.readLine());
	        
	        entrada.Analisa(AndaresPredio);
	        
	        int EmpregadosAndar[]=new int[AndaresPredio];
	        
	        for (int x=0; x<AndaresPredio;x++) {
	        	 EmpregadosAndar[x]=Integer.parseInt(br.readLine());
	        }
	        entrada.Calculos(EmpregadosAndar);
	        entrada.Exibir();
	 }

}
