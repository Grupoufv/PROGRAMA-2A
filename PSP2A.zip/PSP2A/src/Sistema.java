public class Sistema {
	
	private int[] numeros;
	
	private int [] maiores= {0,0};
	
	private int minutos;
	
	private String andar="";
	
	
	boolean TipoCalculo=true; // C�lculo caso geral, um pr�dio de 3 andares
	
	public void  Analisa(int a) {
		if(a==3){
			this.TipoCalculo=true;
		}
		else {
			this.TipoCalculo=false;
			}
	}
	
	public void Calculos(int[] numeros) {
		this.numeros = numeros;	
		CalculoGeral(); 
	}
	
	private void CalculoGeral() {
		// Calcular todas as fun��es e gravar nas vari�veis
		CalcularMinutos();
		CalcularAndar();
	}
	
	 private void CalcularMinutos() {
		 if(this.TipoCalculo==true) {
			 int a=numeros[0];
			 
			 int b=numeros[1];
			 
			 int c=numeros[2];
			 if ((b >= c && b >= a))
		        	this.minutos = (c + a) * 2;
		        else if (c>=a && (a + b) <= c)
		        	this.minutos = (a * 4) + (b * 2);
		        else if (a >= c && (c + b) <= a)
		        	this.minutos = (c * 4) + (b * 2);
		        else 
		        	this.minutos = (c + a) * 2;
		 }
		 else {
			 int maior=numeros[0];
			 
			 for (int i = 0; i < numeros.length; i++) {
				 if(numeros[i]>=maior) {
					 maior=numeros[i];
				 }
				 
			 }
			 
			 this.maiores[0]=maior;
			 
			 int [] ListaSoma=new int[numeros.length];
			 
			 for (int i = 0; i < numeros.length; i++) {
				 if(numeros[i]!=maior) {
					ListaSoma[i]=numeros[i];
				 }
				 
			 }
			 maior=ListaSoma[0];
			 
			 for (int i = 0; i < ListaSoma.length; i++) {
				 if(ListaSoma[i]>=maior) {
					 maior=ListaSoma[i];
				 }
				 
			 }
			 
			 this.maiores[1]=maior;
			 
			
			 int soma=0;
			 for (int i = 0; i < ListaSoma.length; i++) {
				 if(ListaSoma[i]!=maior) {
					 soma+=ListaSoma[i];
				 }
				 
			 }
			 
			 int m1=this.maiores[0];
			 
			 int m2=this.maiores[1];
			 
			 this.minutos=((m1+m2)*2)+soma;
			 
			 
		 }
	 }
	 
	private void CalcularAndar() {
		 if(this.TipoCalculo==true) {
			 int a=numeros[0];
			 
			 int b=numeros[1];
			 
			 int c=numeros[2];
			 
			 if(b>c && b>a) {
				 this.andar=this.andar+2;
			 }
			 
			 if((c>a&&b<c)&&(c-b)>=a) {
				 this.andar=this.andar+2+" "+3;
			 }
			 
			 if((c>a&&b<c)&&(c-b)<a) {
				 this.andar=this.andar+3;
			 }
			 
			 if((a>c && b<a )&&(a-b)<=c) {
				 this.andar=this.andar+1+" "+2;
			 }
			 if((a>c && b<a )&&(a-b)>c) {
				 this.andar=this.andar+1;
			 }
		 }
		 else {
			 int m1=0;
			 
			 int m2=0;
			 
			 for(int i=0;i<numeros.length;i++) {
				 if(numeros[i]==this.maiores[0]) {
					 m1=i;
				 }
				 if(numeros[i]==this.maiores[1]) {
					 m2=i;
				 }
			 }
			 m1+=1;
			 m2+=1;
			 this.andar=this.andar+m1+" "+m2;
		 }
		 
	}	
	
	public int GetMinutos() {
		return this.minutos;
	}
	
	public String GetAndares() {
		return this.andar;
	}
	
	public void Exibir() {
		System.out.println(this.minutos);
		System.out.println(this.andar);
	}
}
