import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testePSP {

	@Test
	public void Teste1()  {
			int[] numeros={10,20,30};
			Sistema sis = new Sistema();;
			sis.Analisa(3);
			sis.Calculos (numeros);
			String argumento="2 3";
			int minutos=80;
			assertEquals(sis.GetMinutos(),minutos);
			assertEquals(sis.GetAndares(),argumento);
		}
	
	@Test
	public void Teste2()  {
			int[] numeros={10,30,20};
			Sistema sis = new Sistema();;
			sis.Analisa(3);
			sis.Calculos (numeros);
			String argumento="2";
			int minutos=60;
			assertEquals(sis.GetMinutos(),minutos);
			assertEquals(sis.GetAndares(),argumento);
		}
	
	@Test
	public void Teste3()  {
			int[] numeros={30,10,20};
			Sistema sis = new Sistema();;
			sis.Analisa(3);
			sis.Calculos (numeros);
			String argumento="1 2";
			int minutos=100;
			assertEquals(sis.GetMinutos(),minutos);
			assertEquals(sis.GetAndares(),argumento);
		}
	
	@Test
	public void Teste4()  {
			int[] numeros={80,50,10,5,15};
			Sistema sis = new Sistema();;
			sis.Analisa(5);
			sis.Calculos (numeros);
			String argumento="1 2";
			int minutos=290;
			assertEquals(sis.GetMinutos(),minutos);
			assertEquals(sis.GetAndares(),argumento);
		}
}
